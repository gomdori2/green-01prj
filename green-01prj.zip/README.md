# 1차 그린 프로젝트

## 식물 일정 관리앱

- 일단 구색 맞추기로 만들어 놓았음.
  - 변경 예정
- 저작권자 표시 : 이미지 - 나중에 팝업으로 변경

- ntl-studio : `[404Page.jpg](https://kr.freepik.com/author/ntl-studio)`

- 파비콘
- `<a href="https://www.flaticon.com/kr/free-icons/" title="화분 아이콘">화분 아이콘 제작자: DinosoftLabs - Flaticon</a>`
- 수정
