const PlantRegisterItem = () => {
  return <div>PlantRegisterItem</div>;
};

export default PlantRegisterItem;
