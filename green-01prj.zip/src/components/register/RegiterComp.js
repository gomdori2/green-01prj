// 명칭 파일 변경하시거나 하시면 되요 충돌나면 그때 수정할께요
const Regiter = () => {
  return <div>Regiter</div>;
};

export default Regiter;
