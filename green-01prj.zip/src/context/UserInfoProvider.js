import React from "react";

const UserInfoProvider = () => {
  return <div></div>;
};

export default UserInfoProvider;
